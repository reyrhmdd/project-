const fetch = require('node-fetch');

exports.handler = async function (event, context) {
  try {
    const formData = JSON.parse(event.body);

    const sheetUrl = "https://script.google.com/macros/s/AKfycbwmzc0zZXrGjgwshvZeZJgfnNknhiFoqdcxDrZPyYzmYHGvFgwIUr8F9w8gmB2BGReD4A/exec"; // Ganti ini

    const response = await fetch(sheetUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(formData)
    });

    const result = await response.json();

    return {
      statusCode: 200,
      body: JSON.stringify({ status: "sukses", result })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ status: "gagal", error: error.message })
    };
  }
};
